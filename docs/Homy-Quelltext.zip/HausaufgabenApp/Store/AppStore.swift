import Foundation
import SwiftUI

/// Hält alle Daten der App und speichert sie als JSON-Datei im Dokumentenordner.
final class AppStore: ObservableObject {

    @Published private(set) var subjects: [Subject]
    @Published private(set) var lessons: [Lesson]
    @Published private(set) var homework: [HomeworkEntry]
    /// Tage, an denen ausdrücklich nichts aufgegeben wurde.
    @Published private(set) var noHomeworkDays: Set<String>
    /// Einzelne Fächer, in denen an einem Tag nichts aufgegeben wurde.
    @Published private(set) var noHomeworkSubjects: Set<String>
    /// Freie Notizen, etwa anstehende Arbeiten.
    @Published private(set) var notes: [Note]
    /// Termine im Kalender.
    @Published private(set) var events: [CalendarEvent]
    /// Ferien mit Anfang und Ende.
    @Published private(set) var holidays: [Holiday]
    /// Die eigenen Angaben – frei änderbar, deshalb ohne private(set).
    @Published var profile: Profile {
        didSet {
            guard profile != oldValue else { return }
            scheduleSave()
        }
    }
    @Published var settings: AppSettings {
        didSet {
            guard settings != oldValue else { return }
            settings.normalizeTimes()
            scheduleSave()
        }
    }

    /// Die Anmeldung: Code, Schnellstart und wann nachgefragt wird.
    /// Bleibt auf diesem Gerät – Sicherungen enthalten sie nicht.
    @Published var lock: LockSettings {
        didSet {
            guard lock != oldValue else { return }
            scheduleSave()
        }
    }

    /// Wird hochgezählt, wenn die Daten komplett ersetzt wurden (Import, Zurücksetzen).
    /// Ansichten hängen sich mit `.id(store.dataRevision)` daran, um sich neu aufzubauen.
    @Published private(set) var dataRevision: Int = 0

    /// Letzter Fehler beim Speichern oder Laden – wird in den Einstellungen angezeigt.
    @Published var lastErrorMessage: String?

    private let fileURL: URL
    private var saveWorkItem: DispatchWorkItem?

    // MARK: - Start

    init(fileURL: URL? = nil) {
        let url = fileURL ?? AppStore.defaultFileURL()
        self.fileURL = url

        let loaded = AppStore.load(from: url) ?? AppData.initial
        var data = loaded
        data.sanitize()

        self.subjects = data.subjects
        self.lessons = data.lessons
        self.homework = data.homework
        self.noHomeworkDays = data.noHomeworkDays
        self.noHomeworkSubjects = data.noHomeworkSubjects
        self.notes = data.notes
        self.events = data.events
        self.holidays = data.holidays
        self.profile = data.profile
        self.settings = data.settings
        self.lock = data.lock

        // Beim allerersten Start die Datei gleich anlegen.
        if !FileManager.default.fileExists(atPath: url.path) {
            saveNow()
        }
    }

    static func defaultFileURL() -> URL {
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        return directory.appendingPathComponent("hausaufgaben.json")
    }

    // MARK: - Fächer

    /// Fächer alphabetisch nach Namen.
    var sortedSubjects: [Subject] {
        subjects.sorted {
            $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending
        }
    }

    func subject(id: UUID?) -> Subject? {
        guard let id else { return nil }
        return subjects.first { $0.id == id }
    }

    func addSubject(_ subject: Subject) {
        subjects.append(subject)
        scheduleSave()
    }

    func updateSubject(_ subject: Subject) {
        guard let index = subjects.firstIndex(where: { $0.id == subject.id }) else { return }
        subjects[index] = subject
        scheduleSave()
    }

    /// Löscht ein Fach samt seiner Stundenplan-Einträge und Hausaufgaben.
    /// Notizen sind davon unabhängig und bleiben unverändert.
    func deleteSubject(id: UUID) {
        subjects.removeAll { $0.id == id }
        lessons.removeAll { $0.subjectID == id }
        homework.removeAll { $0.subjectID == id }
        scheduleSave()
    }

    /// Wie oft ein Fach im Stundenplan steht.
    func lessonCount(forSubject id: UUID) -> Int {
        lessons.filter { $0.subjectID == id }.count
    }

    /// Wie viele Hausaufgaben zu einem Fach gespeichert sind.
    func homeworkCount(forSubject id: UUID) -> Int {
        homework.filter { $0.subjectID == id }.count
    }

    func addStarterSubjects() {
        for subject in Subject.starterSubjects where !subjects.contains(where: {
            $0.displayName.localizedCaseInsensitiveCompare(subject.name) == .orderedSame
        }) {
            subjects.append(subject)
        }
        scheduleSave()
    }

    // MARK: - Stundenplan

    func lesson(weekday: Int, period: Int) -> Lesson? {
        lessons.first { $0.weekday == weekday && $0.period == period }
    }

    /// Legt die Stunde an, ändert sie oder löscht sie, wenn nichts mehr drinsteht.
    func setLesson(weekday: Int, period: Int, subjectID: UUID?, room: String, teacher: String) {
        let trimmedRoom = room.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedTeacher = teacher.trimmingCharacters(in: .whitespacesAndNewlines)
        let index = lessons.firstIndex { $0.weekday == weekday && $0.period == period }

        if subjectID == nil && trimmedRoom.isEmpty && trimmedTeacher.isEmpty {
            if let index { lessons.remove(at: index) }
            scheduleSave()
            return
        }

        if let index {
            lessons[index].subjectID = subjectID
            lessons[index].room = trimmedRoom
            lessons[index].teacher = trimmedTeacher
        } else {
            lessons.append(Lesson(weekday: weekday,
                                  period: period,
                                  subjectID: subjectID,
                                  room: trimmedRoom,
                                  teacher: trimmedTeacher))
        }
        scheduleSave()
    }

    func clearLesson(weekday: Int, period: Int) {
        lessons.removeAll { $0.weekday == weekday && $0.period == period }
        scheduleSave()
    }

    /// Alle belegten Stunden eines Wochentags, nach Stundennummer sortiert.
    func lessons(onWeekday weekday: Int) -> [Lesson] {
        lessons
            .filter { $0.weekday == weekday && $0.subjectID != nil }
            .sorted { $0.period < $1.period }
    }

    /// Die Fächer eines Wochentags in der Reihenfolge des Stundenplans, jedes Fach nur einmal.
    func subjects(onWeekday weekday: Int) -> [Subject] {
        var seen = Set<UUID>()
        var result: [Subject] = []
        for lesson in lessons(onWeekday: weekday) {
            guard let id = lesson.subjectID, !seen.contains(id) else { continue }
            guard let subject = subject(id: id) else { continue }
            seen.insert(id)
            result.append(subject)
        }
        return result
    }

    /// Raum bzw. Lehrkraft der Stunde – mit Rückfall auf die Angaben des Fachs.
    func room(for lesson: Lesson) -> String {
        let own = lesson.room.trimmingCharacters(in: .whitespacesAndNewlines)
        if !own.isEmpty { return own }
        return subject(id: lesson.subjectID)?.room.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }

    func teacher(for lesson: Lesson) -> String {
        let own = lesson.teacher.trimmingCharacters(in: .whitespacesAndNewlines)
        if !own.isEmpty { return own }
        return subject(id: lesson.subjectID)?.teacher.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }

    var hasAnyLesson: Bool { lessons.contains { $0.subjectID != nil } }

    /// Der Tag, um den es gerade geht: heute, wenn heute Unterricht ist,
    /// sonst der nächste Tag mit Stunden. Am Wochenende ist das der Montag.
    /// Gibt `nil` zurück, wenn im ganzen Plan keine Stunde steht.
    func currentSchoolDay(from reference: Date = Date()) -> Date? {
        let start = SchoolCalendar.startOfDay(reference)
        for offset in 0..<7 {
            guard let day = SchoolCalendar.calendar.date(byAdding: .day, value: offset, to: start) else { continue }
            let weekday = SchoolCalendar.weekdayIndex(of: day)
            guard settings.weekdays.contains(weekday) else { continue }
            if !lessons(onWeekday: weekday).isEmpty { return day }
        }
        return nil
    }

    /// Ersetzt den gesamten Stundenplan – wird nach einem geprüften Scan aufgerufen.
    /// Fächer und Hausaufgaben bleiben unangetastet.
    func replaceTimetable(with newLessons: [Lesson]) {
        let validIDs = Set(subjects.map(\.id))
        lessons = newLessons.filter { lesson in
            guard (1...7).contains(lesson.weekday), lesson.period >= 1 else { return false }
            guard let id = lesson.subjectID else { return false }
            return validIDs.contains(id)
        }
        // Der Plan darf nicht mehr Stunden haben, als angezeigt werden.
        if let höchste = lessons.map(\.period).max(), höchste > settings.periodCount {
            settings.periodCount = min(14, höchste)
        }
        if lessons.contains(where: { $0.weekday == 6 }) {
            settings.includeSaturday = true
        }
        dataRevision += 1
        saveNow()
    }

    /// Legt für erkannte, aber unbekannte Kürzel neue Fächer an und gibt zurück,
    /// welches Kürzel zu welchem Fach wurde.
    @discardableResult
    func createSubjects(forCodes codes: [String]) -> [String: UUID] {
        var mapping: [String: UUID] = [:]
        for code in codes {
            let cleaned = code.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleaned.isEmpty else { continue }

            if let existing = subjects.first(where: {
                $0.short.localizedCaseInsensitiveCompare(cleaned) == .orderedSame
            }) {
                mapping[cleaned] = existing.id
                continue
            }

            let subject = Subject(name: cleaned,
                                  short: String(cleaned.prefix(4)),
                                  colorIndex: AppTheme.suggestedColorIndex(usedBy: subjects))
            subjects.append(subject)
            mapping[cleaned] = subject.id
        }
        scheduleSave()
        return mapping
    }

    // MARK: - Hausaufgaben

    func homeworkEntry(day: Date, subjectID: UUID) -> HomeworkEntry? {
        let key = SchoolCalendar.dayKey(day)
        return homework.first { $0.dayKey == key && $0.subjectID == subjectID }
    }

    /// Alle Hausaufgaben eines Tages, sortiert nach der Reihenfolge im Stundenplan.
    func homeworkEntries(on day: Date) -> [HomeworkEntry] {
        let key = SchoolCalendar.dayKey(day)
        let weekday = SchoolCalendar.weekdayIndex(of: day)
        let order = subjects(onWeekday: weekday).map(\.id)
        return homework
            .filter { $0.dayKey == key }
            .sorted { a, b in
                let indexA = order.firstIndex(of: a.subjectID) ?? Int.max
                let indexB = order.firstIndex(of: b.subjectID) ?? Int.max
                if indexA != indexB { return indexA < indexB }
                return a.createdAt < b.createdAt
            }
    }

    /// Fächer, die an diesem Tag im Hausaufgabenblatt auftauchen sollen:
    /// alle Fächer des Stundenplans plus Fächer, zu denen an dem Tag schon etwas eingetragen wurde.
    func homeworkSubjects(on day: Date) -> [Subject] {
        let weekday = SchoolCalendar.weekdayIndex(of: day)
        var result = subjects(onWeekday: weekday)
        var seen = Set(result.map(\.id))

        for entry in homeworkEntries(on: day) where !seen.contains(entry.subjectID) {
            if let subject = subject(id: entry.subjectID) {
                seen.insert(subject.id)
                result.append(subject)
            }
        }
        return result
    }

    /// Schreibt den Text einer Hausaufgabe. Leerer Text löscht den Eintrag.
    /// Ändert nichts, wenn der Text schon so gespeichert ist – dadurch sind
    /// wiederholte Aufrufe aus der Oberfläche unschädlich.
    func setHomeworkText(_ text: String, day: Date, subjectID: UUID) {
        // Eine Ansicht kann noch nachträglich speichern wollen, nachdem das Fach
        // gelöscht wurde – dann darf kein neuer Eintrag entstehen.
        guard subjects.contains(where: { $0.id == subjectID }) else { return }

        let key = SchoolCalendar.dayKey(day)
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let index = homework.firstIndex { $0.dayKey == key && $0.subjectID == subjectID }

        if trimmed.isEmpty {
            guard let index else { return }
            // Ein abgehakter Eintrag ohne Text bleibt bestehen: „erledigt,
            // aber nicht aufgeschrieben“ ist eine gültige Angabe.
            if homework[index].isDone {
                guard homework[index].text != text else { return }
                homework[index].text = text
                homework[index].updatedAt = Date()
            } else {
                homework.remove(at: index)
            }
            scheduleSave()
            return
        }

        if let index {
            guard homework[index].text != text else { return }
            homework[index].text = text
            homework[index].updatedAt = Date()
        } else {
            homework.append(HomeworkEntry(dayKey: key, subjectID: subjectID, text: text))
        }
        // Sobald etwas eingetragen ist, stimmt „nichts auf“ nicht mehr.
        noHomeworkDays.remove(key)
        noHomeworkSubjects.remove(subjectKey(day: day, subjectID: subjectID))
        scheduleSave()
    }

    /// Hakt ein Fach ab. Das geht auch, wenn nichts eingetragen ist –
    /// dann entsteht ein Eintrag ohne Text, der für „erledigt“ steht.
    func setHomeworkDone(_ isDone: Bool, day: Date, subjectID: UUID) {
        guard subjects.contains(where: { $0.id == subjectID }) else { return }
        let key = SchoolCalendar.dayKey(day)

        if let index = homework.firstIndex(where: { $0.dayKey == key && $0.subjectID == subjectID }) {
            guard homework[index].isDone != isDone else { return }
            homework[index].isDone = isDone
            homework[index].updatedAt = Date()
            // Ohne Text und ohne Haken bleibt nichts übrig.
            if !isDone && !homework[index].hasText {
                homework.remove(at: index)
            }
        } else {
            guard isDone else { return }
            homework.append(HomeworkEntry(dayKey: key, subjectID: subjectID, text: "", isDone: true))
        }

        // „Erledigt“ und „keine Hausaufgaben“ schließen sich aus.
        if isDone {
            noHomeworkDays.remove(key)
            noHomeworkSubjects.remove(subjectKey(day: day, subjectID: subjectID))
        }
        scheduleSave()
    }

    func deleteHomework(day: Date, subjectID: UUID) {
        let key = SchoolCalendar.dayKey(day)
        homework.removeAll { $0.dayKey == key && $0.subjectID == subjectID }
        scheduleSave()
    }

    // MARK: - Tage ohne Hausaufgaben

    /// Ist der Tag ausdrücklich als „nichts auf“ vermerkt?
    func isMarkedNoHomework(day: Date) -> Bool {
        noHomeworkDays.contains(SchoolCalendar.dayKey(day))
    }

    func setNoHomework(_ value: Bool, day: Date) {
        let key = SchoolCalendar.dayKey(day)
        if value {
            // Der Vermerk gilt nur, solange nichts eingetragen ist.
            guard !homework.contains(where: { $0.dayKey == key && $0.hasText }) else { return }
            guard !noHomeworkDays.contains(key) else { return }
            noHomeworkDays.insert(key)
        } else {
            guard noHomeworkDays.contains(key) else { return }
            noHomeworkDays.remove(key)
        }
        scheduleSave()
    }

    // MARK: - "Nichts auf" je Fach

    private func subjectKey(day: Date, subjectID: UUID) -> String {
        "\(SchoolCalendar.dayKey(day))|\(subjectID.uuidString)"
    }

    /// Ist für dieses Fach an diesem Tag „nichts auf“ vermerkt?
    func isNoHomework(day: Date, subjectID: UUID) -> Bool {
        noHomeworkSubjects.contains(subjectKey(day: day, subjectID: subjectID))
    }

    /// Vermerkt „keine Hausaufgaben“ für ein Fach. Das geht immer –
    /// ein bereits eingetragener Text wird dabei verworfen, denn beides
    /// zugleich kann nicht stimmen.
    func setNoHomework(_ value: Bool, day: Date, subjectID: UUID) {
        guard subjects.contains(where: { $0.id == subjectID }) else { return }
        let key = subjectKey(day: day, subjectID: subjectID)
        let dayKey = SchoolCalendar.dayKey(day)

        if value {
            homework.removeAll { $0.dayKey == dayKey && $0.subjectID == subjectID }
            guard !noHomeworkSubjects.contains(key) else { return }
            noHomeworkSubjects.insert(key)
        } else {
            guard noHomeworkSubjects.contains(key) else { return }
            noHomeworkSubjects.remove(key)
        }
        scheduleSave()
    }

    /// Sind an dem Tag alle Fächer geklärt – also überall entweder etwas
    /// eingetragen oder „nichts auf“ vermerkt?
    func allSubjectsSettled(on day: Date) -> Bool {
        let faecher = homeworkSubjects(on: day)
        guard !faecher.isEmpty else { return false }
        return faecher.allSatisfy { fach in
            homeworkEntry(day: day, subjectID: fach.id)?.hasText == true
                || isNoHomework(day: day, subjectID: fach.id)
            }
    }

    /// Anzahl offener Hausaufgaben in einer Woche – für die Anzeige im Wochenkopf.
    func openHomeworkCount(weekStart: Date, dayCount: Int) -> Int {
        var count = 0
        for offset in 0..<max(0, dayCount) {
            let day = SchoolCalendar.date(inWeekOf: weekStart, weekday: offset + 1)
            count += homeworkEntries(on: day).filter { !$0.isDone && $0.hasText }.count
        }
        return count
    }

    // MARK: - Suchen

    /// Ein Treffer der Suche – eine Hausaufgabe oder eine Notiz.
    struct SearchResult: Identifiable {
        enum Kind { case homework, note }

        let id: UUID
        let kind: Kind
        let title: String
        let detail: String
        let subjectID: UUID?
        /// Bei Hausaufgaben der Tag, an dem sie steht.
        let day: Date?
        let isDone: Bool
    }

    /// Durchsucht Hausaufgaben und Notizen nach einem Stichwort.
    /// Neueste zuerst, damit das Gesuchte meist oben steht.
    func search(_ query: String) -> [SearchResult] {
        let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard needle.count >= 2 else { return [] }

        var results: [SearchResult] = []

        for entry in homework where entry.hasText {
            guard entry.text.localizedCaseInsensitiveContains(needle) else { continue }
            let day = SchoolCalendar.date(fromDayKey: entry.dayKey)
            let fach = subject(id: entry.subjectID)?.displayName ?? ""
            let datum = day.map { SchoolCalendar.longDate($0) } ?? ""
            results.append(SearchResult(id: entry.id,
                                        kind: .homework,
                                        title: entry.text,
                                        detail: [fach, datum].filter { !$0.isEmpty }.joined(separator: " · "),
                                        subjectID: entry.subjectID,
                                        day: day,
                                        isDone: entry.isDone))
        }

        for note in notes where note.hasText {
            guard note.text.localizedCaseInsensitiveContains(needle) else { continue }
            results.append(SearchResult(id: note.id,
                                        kind: .note,
                                        title: note.title,
                                        detail: note.preview.isEmpty ? "Notiz" : note.preview,
                                        subjectID: nil,
                                        day: nil,
                                        isDone: false))
        }

        return results.sorted { a, b in
            let da = a.day ?? .distantPast
            let db = b.day ?? .distantPast
            if da != db { return da > db }
            return a.title < b.title
        }
    }

    // MARK: - Notizen

    func note(id: UUID?) -> Note? {
        guard let id else { return nil }
        return notes.first { $0.id == id }
    }

    /// Zuletzt geschriebene zuerst – wie in Apples Notizen.
    var sortedNotes: [Note] {
        notes.sorted { $0.updatedAt > $1.updatedAt }
    }

    /// Legt eine leere Notiz an und gibt ihre Kennung zurück,
    /// damit sie sofort zum Schreiben geöffnet werden kann.
    func createNote() -> UUID {
        let note = Note()
        notes.append(note)
        scheduleSave()
        return note.id
    }

    /// Schreibt den Text während des Tippens.
    func setNoteText(_ text: String, id: UUID) {
        guard let index = notes.firstIndex(where: { $0.id == id }),
              notes[index].text != text else { return }
        notes[index].text = text
        notes[index].updatedAt = Date()
        scheduleSave()
    }

    func deleteNote(id: UUID) {
        notes.removeAll { $0.id == id }
        scheduleSave()
    }

    /// Entfernt eine Notiz, in der nichts steht – etwa wenn man sie
    /// anlegt und ohne zu schreiben wieder zurückgeht.
    func discardIfEmpty(id: UUID) {
        guard let index = notes.firstIndex(where: { $0.id == id }),
              !notes[index].hasText else { return }
        notes.remove(at: index)
        scheduleSave()
    }

    // MARK: - Kalender

    /// Termine eines Tages, nach Uhrzeit sortiert – ganztägige zuerst.
    func events(on day: Date) -> [CalendarEvent] {
        let key = SchoolCalendar.dayKey(day)
        return events
            .filter { $0.dayKey == key }
            .sorted { a, b in
                switch (a.startMinutes, b.startMinutes) {
                case (nil, nil):        return a.createdAt < b.createdAt
                case (nil, _):          return true
                case (_, nil):          return false
                case let (x?, y?):      return x == y ? a.createdAt < b.createdAt : x < y
                }
            }
    }

    func event(id: UUID?) -> CalendarEvent? {
        guard let id else { return nil }
        return events.first { $0.id == id }
    }

    /// Gibt es an dem Tag überhaupt etwas?
    func hasEvents(on day: Date) -> Bool {
        let key = SchoolCalendar.dayKey(day)
        return events.contains { $0.dayKey == key }
    }

    /// Die nächsten Termine ab heute – für die Übersicht über dem Kalender.
    func upcomingEvents(limit: Int = 5, from reference: Date = Date()) -> [CalendarEvent] {
        let heute = SchoolCalendar.dayKey(SchoolCalendar.startOfDay(reference))
        return events
            .filter { $0.dayKey >= heute }
            .sorted { a, b in
                if a.dayKey != b.dayKey { return a.dayKey < b.dayKey }
                return (a.startMinutes ?? -1) < (b.startMinutes ?? -1)
            }
            .prefix(limit)
            .map { $0 }
    }

    /// Wie viele Tage es noch bis zu dem Termin sind (0 = heute).
    func daysUntil(_ event: CalendarEvent, from reference: Date = Date()) -> Int? {
        guard let day = event.date else { return nil }
        return SchoolCalendar.calendar.dateComponents(
            [.day],
            from: SchoolCalendar.startOfDay(reference),
            to: SchoolCalendar.startOfDay(day)).day
    }

    /// Legt einen Termin an oder ersetzt einen bestehenden.
    func saveEvent(_ event: CalendarEvent) {
        var event = event
        event.updatedAt = Date()

        if let index = events.firstIndex(where: { $0.id == event.id }) {
            events[index] = event
        } else {
            events.append(event)
        }
        scheduleSave()
        syncReminders()
    }

    func deleteEvent(id: UUID) {
        events.removeAll { $0.id == id }
        scheduleSave()
        syncReminders()
    }

    // MARK: - Ferien

    /// Ferien, die nächsten zuerst – vorbei ist ganz unten.
    var sortedHolidays: [Holiday] {
        holidays.sorted { a, b in
            let aVorbei = a.isOver(), bVorbei = b.isOver()
            if aVorbei != bVorbei { return !aVorbei }
            return a.startDayKey < b.startDayKey
        }
    }

    /// In welchen Ferien liegt dieser Tag?
    func holiday(on day: Date) -> Holiday? {
        holidays.first { $0.contains(day) }
    }

    /// Die Ferien, die gerade laufen.
    func currentHoliday(on reference: Date = Date()) -> Holiday? {
        holiday(on: reference)
    }

    /// Die nächsten Ferien, die noch nicht angefangen haben.
    func nextHoliday(from reference: Date = Date()) -> Holiday? {
        let heute = SchoolCalendar.startOfDay(reference)
        return holidays
            .filter { ($0.orderedDates?.start ?? .distantPast) > heute }
            .min { ($0.orderedDates?.start ?? .distantFuture) < ($1.orderedDates?.start ?? .distantFuture) }
    }

    /// Wie viele Tage es noch bis zum ersten Ferientag sind.
    func daysUntilStart(of holiday: Holiday, from reference: Date = Date()) -> Int? {
        guard let (start, _) = holiday.orderedDates else { return nil }
        return SchoolCalendar.calendar.dateComponents(
            [.day], from: SchoolCalendar.startOfDay(reference), to: start).day
    }

    /// Der erste Tag nach `day`, an dem wirklich Schule ist: Wochenenden
    /// und andere Ferien werden übersprungen.
    ///
    /// `ignoring` lässt Ferien aus – gebraucht beim Bearbeiten, wo die alten
    /// Angaben noch gespeichert sind.
    func firstSchoolDay(after day: Date, ignoring holidayID: UUID? = nil) -> Date? {
        let schultage = Set(settings.weekdays)
        var kandidat = SchoolCalendar.startOfDay(day)

        // Ein Jahr weit suchen; danach ist etwas anderes im Argen.
        for _ in 0..<366 {
            guard let naechster = SchoolCalendar.calendar.date(byAdding: .day, value: 1, to: kandidat) else {
                return nil
            }
            kandidat = naechster
            guard schultage.contains(SchoolCalendar.weekdayIndex(of: kandidat)) else { continue }
            let inFerien = holidays.contains { $0.id != holidayID && $0.contains(kandidat) }
            if inFerien { continue }
            if publicHoliday(on: kandidat) != nil { continue }
            return kandidat
        }
        return nil
    }

    /// Der erste Schultag nach diesen Ferien.
    func firstSchoolDay(after holiday: Holiday) -> Date? {
        guard let (_, end) = holiday.orderedDates else { return nil }
        return firstSchoolDay(after: end, ignoring: holiday.id)
    }

    // MARK: - Gesetzliche Feiertage

    /// Ist dieser Tag ein gesetzlicher Feiertag im eingestellten Bundesland?
    ///
    /// Diese Tage rechnet Homy selbst aus – eingetragen werden müssen nur
    /// die Schulferien.
    func publicHoliday(on day: Date) -> PublicHoliday? {
        PublicHolidays.holiday(on: day, state: settings.federalState)
    }

    /// Die nächsten Feiertage – für die Vorschau in den Einstellungen.
    func upcomingPublicHolidays(limit: Int = 4) -> [PublicHoliday] {
        PublicHolidays.upcoming(state: settings.federalState, limit: limit)
    }

    /// Ist an diesem Tag schulfrei, und wie heißt der Tag?
    /// Deckt Ferien und Feiertage ab – beides ist in Homy grün.
    func freeDayName(on day: Date) -> String? {
        if let ferien = holiday(on: day) { return ferien.displayName }
        if let feiertag = publicHoliday(on: day) { return feiertag.name }
        return nil
    }

    /// Ist an diesem Tag überhaupt Schule?
    func isSchoolFree(on day: Date) -> Bool {
        freeDayName(on: day) != nil
    }

    func saveHoliday(_ holiday: Holiday) {
        var holiday = holiday
        holiday.updatedAt = Date()
        // Vertauschte Angaben gleich geradeziehen.
        if let (start, end) = holiday.orderedDates {
            holiday.startDayKey = SchoolCalendar.dayKey(start)
            holiday.endDayKey = SchoolCalendar.dayKey(end)
        }

        if let index = holidays.firstIndex(where: { $0.id == holiday.id }) {
            holidays[index] = holiday
        } else {
            holidays.append(holiday)
        }
        scheduleSave()
        syncReminders()
    }

    func deleteHoliday(id: UUID) {
        holidays.removeAll { $0.id == id }
        scheduleSave()
        syncReminders()
    }

    // MARK: - Erinnerungen

    /// Übergibt iOS die anstehenden Erinnerungen – nach jeder Änderung
    /// und einmal beim Start, damit beides immer zusammenpasst.
    func syncReminders() {
        let namen = Dictionary(uniqueKeysWithValues: subjects.map { ($0.id, $0.displayName) })
        var liste = events.compactMap { event in
            event.reminderItem(subjectName: event.subjectID.flatMap { namen[$0] })
        }
        liste.append(contentsOf: holidays.compactMap(\.reminderItem))

        let erlaubt = settings.remindersEnabled
        Task {
            await Reminders.reschedule(items: liste, enabled: erlaubt)
        }
    }

    // MARK: - Daten ersetzen

    func replaceAll(with data: AppData) {
        var data = data
        data.sanitize()
        subjects = data.subjects
        lessons = data.lessons
        homework = data.homework
        noHomeworkDays = data.noHomeworkDays
        noHomeworkSubjects = data.noHomeworkSubjects
        notes = data.notes
        events = data.events
        holidays = data.holidays
        profile = data.profile
        settings = data.settings
        // Die Anmeldung bleibt, wie sie auf diesem Gerät eingestellt ist:
        // Eine fremde Sicherung soll den eigenen Code weder setzen noch aufheben.
        dataRevision += 1
        saveNow()
        syncReminders()
    }

    func resetToFactoryDefaults() {
        replaceAll(with: AppData.initial)
    }

    func deleteAllHomework() {
        homework.removeAll()
        noHomeworkDays.removeAll()
        noHomeworkSubjects.removeAll()
        dataRevision += 1
        saveNow()
    }

    /// Alles, was in die Datei auf dem Gerät gehört.
    var currentData: AppData {
        AppData(subjects: subjects,
                lessons: lessons,
                homework: homework,
                noHomeworkDays: noHomeworkDays,
                noHomeworkSubjects: noHomeworkSubjects,
                notes: notes,
                events: events,
                holidays: holidays,
                profile: profile,
                settings: settings,
                lock: lock)
    }

    /// Dasselbe für eine Sicherungsdatei – aber ohne die Anmeldung.
    /// So lässt sich aus einer Sicherung kein Code mitnehmen oder aufheben.
    var exportableData: AppData {
        var data = currentData
        data.lock = LockSettings()
        return data
    }

    // MARK: - Speichern und Laden

    private static func makeEncoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }

    private static func makeDecoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }

    /// JSON für Sicherungsdateien.
    func exportData() throws -> Data {
        try AppStore.makeEncoder().encode(exportableData)
    }

    /// Liest eine Sicherungsdatei ein.
    static func decode(_ data: Data) throws -> AppData {
        try makeDecoder().decode(AppData.self, from: data)
    }

    private static func load(from url: URL) -> AppData? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        do {
            let data = try Data(contentsOf: url)
            return try makeDecoder().decode(AppData.self, from: data)
        } catch {
            // Beschädigte Datei zur Seite legen, statt sie stillschweigend zu überschreiben.
            let backupURL = url.deletingPathExtension()
                .appendingPathExtension("beschaedigt-\(Int(Date().timeIntervalSince1970)).json")
            try? FileManager.default.moveItem(at: url, to: backupURL)
            return nil
        }
    }

    /// Sammelt Änderungen kurz, damit beim Tippen nicht bei jedem Zeichen geschrieben wird.
    private func scheduleSave() {
        saveWorkItem?.cancel()
        let workItem = DispatchWorkItem { [weak self] in
            self?.saveNow()
        }
        saveWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4, execute: workItem)
    }

    /// Schreibt sofort auf die Platte – beim Verlassen der App und nach großen Änderungen.
    func saveNow() {
        saveWorkItem?.cancel()
        saveWorkItem = nil
        do {
            let data = try AppStore.makeEncoder().encode(currentData)
            try data.write(to: fileURL, options: [.atomic])
            if lastErrorMessage != nil { lastErrorMessage = nil }
        } catch {
            lastErrorMessage = "Die Daten konnten nicht gespeichert werden: \(error.localizedDescription)"
        }
    }
}
